//
//  OptionsViewController.h
//  DemoApp
//
//  Created by Rene Jay Taboada on 11/6/13.
//  Copyright (c) 2013 reneboi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OptionsViewController : UITableViewController


@property (nonatomic, strong) NSArray *list;


@end
